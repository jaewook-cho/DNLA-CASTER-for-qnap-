const BUILD="3.14.2";
let cur="",pending=null,lastPlayed=null,renderers=[],selected=null,$=x=>document.getElementById(x);
async function init(){let s=await(await fetch("/api/settings?ts="+Date.now(),{cache:"no-store"})).json();selected=s.renderer||null;updateCurrent();loadFiles();if(!selected)scan()}
function tab(x){for(let s of ["nas","tunein","youtube"])$(s).hidden=s!==x;document.querySelectorAll(".tab[data-tab]").forEach(b=>b.classList.toggle("active",b.dataset.tab===x));if(x==="nas")loadFiles(cur);if(x==="tunein")loadTuneInBrowse()}
function updateCurrent(){$("current").textContent=selected?"🔊 "+selected.name:"🔊 리시버 미선택"}
async function scan(){
  try{
    renderers=await(await fetch("/api/renderers?ts="+Date.now(),{cache:"no-store"})).json();
    renderers.sort((a,b)=>a.name.localeCompare(b.name));
    if(selected){let f=renderers.find(x=>x.location===selected.location);if(f)selected=f;updateCurrent()}
    return renderers;
  }catch(e){renderers=[];return []}
}
async function changeReceiver(){
  $("modalTitle").textContent="DLNA 리시버 변경";
  $("modalHint").textContent=lastPlayed?"새 리시버를 선택하면 현재 재생 중인 항목도 새 기기로 이동합니다.":"새 리시버를 선택하면 이후 재생은 선택한 기기로 전송됩니다.";
  $("modal").hidden=false;
  await scanAndShowDevices();
}
async function scanAndShowDevices(){
  $("devices").textContent="DLNA 리시버 검색 중...";
  await scan();
  showDevices();
}
async function loadFiles(p=""){cur=p;let d=await(await fetch("/api/files?path="+encodeURIComponent(p))).json();$("path").textContent="/"+p;let up=p?`<div class="item"><div class="item-main"><span class="item-title">상위 폴더</span></div><button onclick="loadFiles('${esc(p.split('/').slice(0,-1).join('/'))}')">↑ 열기</button></div>`:"";$("files").innerHTML=up+d.items.map(x=>`<div class="item"><div class="${x.dir?'folder-icon':'audio-icon'}">${x.dir?'▰':'♫'}</div><div class="item-main"><span class="item-title">${esc(x.name)}</span><span class="item-sub">${x.dir?'폴더':(x.mime||'audio')}</span></div>${x.dir?`<button onclick="loadFiles('${esc(x.path)}')">열기</button>`:`<span class="file-actions"><button onclick="choose('${esc(x.path)}','${esc(x.name)}','${x.mime}')">재생</button>${((x.mime||'').toLowerCase()==='audio/flac'||(x.mime||'').toLowerCase()==='audio/x-flac'||x.name.toLowerCase().endsWith('.flac'))?`<button class="secondary" onclick="chooseFlacDirect('${esc(x.path)}','${esc(x.name)}')">FLAC 직접</button>`:''}</span>`}</div>`).join("")||`<div class="hint">재생 가능한 파일이 없습니다.</div>`} 
function esc(s){return String(s).replaceAll("\\","\\\\").replaceAll("'","\\'").replaceAll('"','&quot;').replaceAll("`","\\`")}
function choose(p,t,mime){let audio=mime.startsWith("audio/");let enc=p.split("/").map(encodeURIComponent).join("/");let media=audio?`${location.origin}/stream/audio/${enc}`:`${location.origin}/media/${enc}`;pending={media_url:media,title:t,mime:audio?"audio/mpeg":mime,kind:mime.startsWith("video")?"video":"audio"};go()}
function chooseFlacDirect(p,t){let enc=p.split("/").map(encodeURIComponent).join("/");pending={media_url:`${location.origin}/stream/audio-direct/${enc}`,title:t,mime:"audio/flac",kind:"audio"};toast("FLAC 원본을 DLNA로 직접 전송합니다…");go()}
function chooseRadio(u,t){pending={media_url:decodeURIComponent(u),title:t,mime:"audio/mpeg",kind:"audio"};go()}
async function go(){if(selected){await send();}else{$("modalTitle").textContent="DLNA 리시버 선택";$('modalHint').textContent="재생할 DLNA 리시버를 선택하세요.";$('modal').hidden=false;await scanAndShowDevices()}}
function showDevices(){
  $("devices").innerHTML=renderers.map((x,i)=>{
    let mark=selected&&selected.location===x.location?" ✓ 현재":"";
    return `<button class=device onclick="selectDevice(${i})">🔊 ${esc(x.name)}${mark}<br><small>${esc(x.location)}</small></button>`;
  }).join("")||"<div class=hint>리시버를 찾지 못했습니다. 네트워크/SSDP를 확인하세요.</div>";
}
async function selectDevice(i){
  if(!renderers[i])return;
  const old=selected;
  selected=renderers[i];
  let r=await fetch("/api/settings",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({renderer:selected})});
  if(!r.ok){alert(await r.text());return}
  updateCurrent();
  closeModal();
  // A receiver change now actively migrates the last selected/current item.
  if(lastPlayed){pending={...lastPlayed};await send();}
  else if(pending)await send();
}
async function send(){
  if(!selected||!pending)return;
  let p={...pending};
  if(!p.media_url&&p.url)p.media_url=p.url;
  delete p.url;delete p.youtube_url;
  let r=await fetch("/api/play",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({renderer_url:selected.location,...p})});
  if(!r.ok){alert(await r.text());return}
  lastPlayed={...p};
  $("player").hidden=false;$('now').textContent="▶ "+p.title;
}
async function ctl(a){if(!selected)return alert("DLNA 리시버를 먼저 선택하세요.");let r=await fetch("/api/control",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({renderer_url:selected.location,action:a})});if(!r.ok)alert(await r.text())}
async function volume(v){if(!selected)return;let r=await fetch("/api/volume",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({renderer_url:selected.location,action:"volume",value:v})});if(!r.ok)alert(await r.text())}
async function searchYT(){let q=$("q").value.trim();if(!q)return alert("검색어를 입력하세요.");let r=await fetch("/api/youtube",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({q})});if(!r.ok){alert(await r.text());return}let a=await r.json();$("yt").innerHTML=a.map(x=>`<div class=item><span>▶ ${esc(x.title)}</span><button onclick="ytplay('${encodeURIComponent(x.url)}','${esc(x.title)}')">재생</button></div>`).join("")||"검색 결과가 없습니다."}
function ytplay(u,t){toast("YouTube 오디오 스트림 준비 중…");pending={media_url:`${location.origin}/stream/youtube?url=${u}`,title:t,mime:"audio/mpeg",kind:"audio"};go()}
let tuneInStack=[];
async function loadTuneInBrowse(url="",label="카테고리"){
  $("tuneinResults").innerHTML="카테고리 불러오는 중...";
  let r=await fetch("/api/tunein/browse?url="+encodeURIComponent(url),{cache:"no-store"});
  if(!r.ok){$("tuneinResults").textContent=await r.text();return}
  let a=await r.json();
  $("tuneinCrumb").textContent=label;
  let back=url&&tuneInStack.length?`<div class=item><div class=item-main><span class=item-title>상위 카테고리</span></div><button onclick="tuneInBack()">↑ 열기</button></div>`:"";
  $("tuneinResults").innerHTML=back+a.map(x=>x.kind==="folder"?`<div class=item><div class="folder-icon">▰</div><div class=item-main><span class=item-title>${esc(x.name)}</span><span class=item-sub>카테고리</span></div><button onclick="openTuneInFolder('${encodeURIComponent(x.url)}','${esc(x.name)}')">열기</button></div>`:`<div class=item><span>📻 ${esc(x.name)}</span><button onclick="playTuneIn('${esc(x.id)}','${esc(x.name)}')">재생</button></div>`).join("")||`<div class=hint>이 카테고리에 항목이 없습니다.</div>`;
}
function openTuneInFolder(u,label){tuneInStack.push({url:decodeURIComponent(u),label:$("tuneinCrumb").textContent});loadTuneInBrowse(decodeURIComponent(u),label)}
function tuneInBack(){let prev=tuneInStack.pop();if(prev)loadTuneInBrowse(prev.url,prev.label);else loadTuneInBrowse()}
async function searchTuneIn(){let q=$("tq").value.trim();if(!q)return alert("검색어를 입력하세요.");$("tuneinResults").innerHTML="검색 중...";let r=await fetch("/api/tunein/search",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({q})});if(!r.ok){$("tuneinResults").textContent=await r.text();return}let a=await r.json();$("tuneinResults").innerHTML=a.map(x=>`<div class=item><span>📻 ${esc(x.name)} <small>${esc(x.id)}</small></span><button onclick="playTuneIn('${esc(x.id)}','${esc(x.name)}')">재생</button></div>`).join("")||"검색 결과가 없습니다."}
async function playTuneIn(id,name){$("tuneinResults").insertAdjacentHTML("afterbegin",`<div class=hint id="tloading">${esc(name)} 스트림 준비 중...</div>`);let r=await fetch(`/api/tunein/station/${encodeURIComponent(id)}?ts=${Date.now()}`,{cache:"no-store"});$("tloading")?.remove();if(!r.ok){alert(await r.text());return}let x=await r.json();pending={media_url:x.stream_url,title:x.name||name,mime:"audio/mpeg",kind:"audio"};go()}
function closeModal(){$("modal").hidden=true}
init();

function toast(msg){const x=$("toast");x.textContent=msg;x.hidden=false;clearTimeout(window._toast);window._toast=setTimeout(()=>x.hidden=true,2200)}
