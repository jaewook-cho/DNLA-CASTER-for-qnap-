import os, socket, asyncio, mimetypes, urllib.parse, xml.etree.ElementTree as ET, subprocess, hashlib, re, time, threading
from pathlib import Path
import httpx
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import HTMLResponse, FileResponse, StreamingResponse, RedirectResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

APP_PORT=int(os.getenv("APP_PORT","8090"))
NAS_ROOT=Path(os.getenv("NAS_ROOT","/media")).resolve()
QNAP_IP=os.getenv("QNAP_IP","192.168.0.20")
MEDIA_BASE_URL=os.getenv("MEDIA_BASE_URL",f"http://{QNAP_IP}:{APP_PORT}/media")
PUBLIC_STREAM_BASE_URL=os.getenv("PUBLIC_STREAM_BASE_URL",f"http://{QNAP_IP}:{APP_PORT}")
ENABLE_TRANSCODE=os.getenv("ENABLE_FFMPEG_TRANSCODE","true").lower()=="true"
DATA=Path("/app/data"); DATA.mkdir(exist_ok=True)
RADIO_FILE=DATA/"radios.json"
SETTINGS_FILE=DATA/"settings.json"

app=FastAPI(title="DLNA Home Cast v3.14.2")
app.mount("/static",StaticFiles(directory="app/static"),name="static")

class PlayRequest(BaseModel):
    renderer_url:str
    media_url:str
    title:str="DLNA Web"
    mime:str="audio/mpeg"
    kind:str="audio"

class ControlRequest(BaseModel):
    renderer_url:str
    action:str
    value:str|None=None

class SearchRequest(BaseModel):
    q:str

TUNEIN_BASE=os.getenv("TUNEIN_API_BASE","https://opml.radiotime.com")
YOUTUBE_CACHE={}
YOUTUBE_CACHE_LOCK=threading.Lock()
YOUTUBE_CACHE_TTL=300

def _xml_local(tag):
    return tag.rsplit("}",1)[-1].lower()

def _flatten_outlines(root):
    out=[]
    for e in root.iter():
        if _xml_local(e.tag)=="outline":
            a={k.lower():v for k,v in e.attrib.items()}
            out.append(a)
    return out

def _station_id(a):
    for k in ("guide_id","guideid","stationid","id"):
        v=a.get(k)
        if v and (str(v).startswith("s") or str(v).isdigit()):
            return str(v) if str(v).startswith("s") else "s"+str(v)
    u=a.get("url","")
    m=__import__('re').search(r'[/&?](s\d+)(?:[/&?]|$)',u)
    return m.group(1) if m else None

async def tunein_get(path, params=None):
    # Accept either an endpoint path (Browse.ashx) or a validated absolute TuneIn URL.
    if str(path).startswith(("http://", "https://")):
        url=str(path)
    else:
        url=TUNEIN_BASE.rstrip("/")+"/"+str(path).lstrip("/")
    async with httpx.AsyncClient(timeout=12,follow_redirects=True) as client:
        r=await client.get(url,params=params or {})
        r.raise_for_status()
        return r

def _parse_tunein_response(text, content_type=""):
    text=text.lstrip("\ufeff \t\r\n")
    ct=(content_type or "").lower()
    if "json" in ct or text.startswith("{") or text.startswith("["):
        import json
        return json.loads(text)
    # TuneIn may return XML, M3U, a plain stream URL, or an HTTP redirect target.
    if text.startswith(("http://","https://")) and "\n" not in text:
        return {"__stream_urls__":[text.strip()]}
    urls=[]
    for line in text.splitlines():
        line=line.strip()
        if line and not line.startswith("#") and line.startswith(("http://","https://")):
            urls.append(line)
    if urls:
        return {"__stream_urls__":urls}
    if text.startswith("<"):
        return ET.fromstring(text)
    # Some endpoints prepend non-XML text; try extracting the first URL before failing.
    m=re.search(r'https?://[^\s<>\"]+', text)
    if m:
        return {"__stream_urls__":[m.group(0)]}
    raise ValueError("TuneIn 응답 형식을 해석할 수 없습니다")

def _json_outlines(obj):
    out=[]
    def walk(x):
        if isinstance(x,dict):
            keys={str(k).lower():v for k,v in x.items()}
            if any(k in keys for k in ("guide_id","stationid","url","text","title")):
                out.append({k:str(v) for k,v in keys.items() if isinstance(v,(str,int,float))})
            for v in x.values(): walk(v)
        elif isinstance(x,list):
            for v in x: walk(v)
    walk(obj); return out

def _pick_stream(outlines):
    candidates=[]
    for a in outlines:
        u=a.get("url") or a.get("streamurl") or a.get("stream_url")
        if not u or not u.startswith(("http://","https://")): continue
        typ=(a.get("type") or a.get("mediatype") or "").lower()
        mime=(a.get("contenttype") or a.get("mime") or "").lower()
        score=0
        if "audio" in typ or "audio" in mime: score+=5
        if any(x in u.lower() for x in (".mp3",".aac",".m3u8",".pls",".m3u",".ogg",".opus",":80",":443")): score+=2
        if "tune.ashx" in u.lower() or "opml.radiotime.com" in u.lower(): score-=3
        candidates.append((score,u,mime or "audio/mpeg"))
    return max(candidates,key=lambda x:x[0]) if candidates else None

def safe_path(rel):
    p=(NAS_ROOT/rel.lstrip("/")).resolve()
    if p!=NAS_ROOT and NAS_ROOT not in p.parents: raise HTTPException(403,"Invalid path")
    return p

def read_settings():
    if SETTINGS_FILE.exists():
        try: return __import__("json").loads(SETTINGS_FILE.read_text())
        except: pass
    return {"renderer":None}

def write_settings(x):
    SETTINGS_FILE.write_text(__import__("json").dumps(x,ensure_ascii=False,indent=2),encoding="utf-8")

async def discover():
    msg=("M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\n"
         'MAN: "ssdp:discover"\r\nMX: 1\r\n'
         "ST: urn:schemas-upnp-org:device:MediaRenderer:1\r\n\r\n").encode()
    loop=asyncio.get_running_loop()
    s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM,socket.IPPROTO_UDP)
    s.setsockopt(socket.SOL_SOCKET,socket.SO_BROADCAST,1); s.settimeout(2)
    await loop.run_in_executor(None,lambda:s.sendto(msg,("239.255.255.250",1900)))
    found={}
    end=loop.time()+2
    while loop.time()<end:
        try: data,_=await loop.run_in_executor(None,s.recvfrom,65535)
        except: break
        h={}
        for line in data.decode("utf-8","ignore").split("\r\n")[1:]:
            if ":" in line:
                k,v=line.split(":",1); h[k.lower().strip()]=v.strip()
        if h.get("location"): found[h["location"]]=h
    s.close()
    out=[]
    for loc,h in found.items():
        name=h.get("server","DLNA Renderer")
        services=[]
        try:
            r=httpx.get(loc,timeout=3); root=ET.fromstring(r.text)
            n=next((e.text for e in root.iter() if e.tag.endswith("friendlyName")),None)
            name=n or name
            for svc in root.iter():
                if svc.tag.endswith("service"):
                    st=svc.findtext("./{*}serviceType")
                    cu=svc.findtext("./{*}controlURL")
                    if st and cu: services.append({"type":st,"control":urllib.parse.urljoin(loc,cu)})
        except: pass
        if any("AVTransport" in x["type"] for x in services):
            out.append({"name":name,"location":loc,"services":services})
    return out

def control_url(device_url, service_name="AVTransport"):
    r=httpx.get(device_url,timeout=4); r.raise_for_status()
    root=ET.fromstring(r.text)
    for svc in root.iter():
        if svc.tag.endswith("service"):
            st=svc.findtext("./{*}serviceType"); cu=svc.findtext("./{*}controlURL")
            if st and service_name in st and cu: return urllib.parse.urljoin(device_url,cu)
    raise RuntimeError(service_name+" not found")

def soap(url,action,body,service="AVTransport"):
    env='<?xml version="1.0"?><s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/"><s:Body><u:%s xmlns:u="urn:schemas-upnp-org:service:%s:1">%s</u:%s></s:Body></s:Envelope>'%(action,service,body,action)
    r=httpx.post(url,content=env.encode(),headers={"Content-Type":"text/xml; charset=utf-8","SOAPACTION":f'"urn:schemas-upnp-org:service:{service}:1#{action}"'},timeout=8)
    r.raise_for_status()
    return r

def didl(title,url,mime,kind):
    import xml.sax.saxutils as sax
    cls="object.item.videoItem" if kind=="video" else "object.item.audioItem.musicTrack"
    return f'<DIDL-Lite xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:upnp="urn:schemas-upnp-org:metadata-1-0/upnp/" xmlns="urn:schemas-upnp-org:metadata-1-0/DIDL-Lite/"><item id="1" parentID="0" restricted="1"><dc:title>{sax.escape(title)}</dc:title><upnp:class>{cls}</upnp:class><res protocolInfo="http-get:*:{sax.escape(mime)}:*">{sax.escape(url)}</res></item></DIDL-Lite>'

@app.get("/",response_class=HTMLResponse)
def index():
    html=Path("app/static/index.html").read_text(encoding="utf-8")
    return HTMLResponse(html,headers={"Cache-Control":"no-store, no-cache, must-revalidate, max-age=0"})

@app.get("/api/info")
def info():
    return {"qnap_ip":QNAP_IP,"port":APP_PORT,"media_base_url":MEDIA_BASE_URL}

@app.get("/api/settings")
def settings(): return read_settings()

@app.post("/api/settings")
def save_settings(body:dict):
    write_settings(body); return read_settings()

@app.get("/api/renderers")
async def renderers(): return await discover()

@app.get("/api/files")
def files(path=""):
    p=safe_path(path)
    if not p.is_dir(): raise HTTPException(404)
    exts={".mp3",".flac",".m4a",".aac",".wav",".ogg",".opus",".mp4",".mkv",".webm",".mov",".avi",".ts"}
    items=[]
    for x in sorted(p.iterdir(),key=lambda z:(not z.is_dir(),z.name.lower())):
        rel=str(x.relative_to(NAS_ROOT))
        if x.is_dir(): items.append({"name":x.name,"path":rel,"dir":True})
        elif x.suffix.lower() in exts:
            items.append({"name":x.name,"path":rel,"dir":False,"size":x.stat().st_size,"mime":mimetypes.guess_type(str(x))[0] or "application/octet-stream"})
    return {"path":path,"items":items}

def _audio_transcode_response(p:Path):
    cache_dir=DATA/"transcode"; cache_dir.mkdir(exist_ok=True)
    key=hashlib.sha256(str(p).encode()+str(p.stat().st_mtime_ns).encode()).hexdigest()+".mp3"
    out=cache_dir/key
    if not out.exists() or out.stat().st_size<1024:
        tmp=out.with_suffix(".tmp.mp3")
        r=subprocess.run(["ffmpeg","-y","-hide_banner","-loglevel","error","-i",str(p),"-vn","-map_metadata","0","-c:a","libmp3lame","-b:a","320k",str(tmp)],capture_output=True)
        if r.returncode!=0:
            try: tmp.unlink()
            except: pass
            raise HTTPException(500,"FFmpeg 음원 변환 실패: "+r.stderr.decode("utf-8","ignore")[-800:])
        tmp.replace(out)
    return FileResponse(out,media_type="audio/mpeg",filename=p.stem+".mp3",headers={"Cache-Control":"no-store"})

@app.get("/media/{path:path}")
def media(path):
    p=safe_path(path)
    if not p.is_file(): raise HTTPException(404)
    mime=mimetypes.guess_type(str(p))[0] or "application/octet-stream"
    if ENABLE_TRANSCODE and mime.startswith("audio/") and p.suffix.lower() != ".mp3":
        return _audio_transcode_response(p)
    return FileResponse(p,media_type=mime)



@app.get("/api/tunein/browse")
async def tunein_browse(url: str = ""):
    """Browse TuneIn directory. Search remains separate. Prefer TuneIn JSON output for reliable parsing."""
    from urllib.parse import urlparse, parse_qs
    try:
        params = {"render": "json"}
        if url:
            u = urlparse(url)
            base = urlparse(TUNEIN_BASE)
            if u.netloc.lower() != base.netloc.lower() or u.path.lower() != "/browse.ashx":
                raise HTTPException(400, "허용되지 않은 TuneIn browse URL입니다.")
            q = parse_qs(u.query)
            for k in ("c", "id", "filter"):
                if q.get(k):
                    params[k] = q[k][-1]

        # Do not pass the complete URL into tunein_get(). Build the request here so
        # TuneIn's render=json is always requested and nested outlines are preserved.
        r = await tunein_get("Browse.ashx", params)
        parsed = _parse_tunein_response(r.text, r.headers.get("content-type", ""))

        # Normalize all TuneIn response formats into a flat outline list.
        if isinstance(parsed, ET.Element):
            outlines = _flatten_outlines(parsed)
        elif isinstance(parsed, (dict, list)):
            outlines = _json_outlines(parsed)
        else:
            outlines = []

        items = []
        seen = set()
        for a in outlines:
            keys = {str(k).lower(): v for k, v in a.items()}
            typ = str(keys.get("type", "")).lower()
            item_type = str(keys.get("item", "")).lower()
            text = keys.get("text") or keys.get("title") or keys.get("name")
            href = keys.get("url") or keys.get("href")
            sid = _station_id(keys)
            if not text:
                continue
            text = str(text)

            # Real station outline: type="audio" and/or item="station".
            if sid and (typ == "audio" or item_type == "station"):
                key = ("station", sid)
                if key not in seen:
                    items.append({
                        "kind": "station",
                        "id": sid,
                        "name": text,
                        "logo": keys.get("image") or keys.get("imageurl") or keys.get("logo"),
                    })
                    seen.add(key)
                continue

            # Folder/category outline. TuneIn may return http or https and may
            # include additional query parameters; the next request filters them.
            if href and isinstance(href, str):
                hu = urlparse(href)
                if hu.netloc.lower() == urlparse(TUNEIN_BASE).netloc.lower() and hu.path.lower() == "/browse.ashx":
                    normalized = href.replace("http://", "https://", 1)
                    key = ("folder", normalized)
                    if key not in seen:
                        items.append({"kind": "folder", "name": text, "url": normalized})
                        seen.add(key)

        return items
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(502, f"TuneIn 카테고리 불러오기 실패: {type(e).__name__}: {e}")

@app.post("/api/tunein/search")
async def tunein_search(req:SearchRequest):
    q=req.q.strip()
    if not q: raise HTTPException(400,"검색어를 입력하세요")
    try:
        r=await tunein_get("Search.ashx",{"query":q,"render":"json"})
        parsed=_parse_tunein_response(r.text,r.headers.get("content-type",""))
        outlines=_json_outlines(parsed) if isinstance(parsed,(dict,list)) else _flatten_outlines(parsed)
        results=[]; seen=set()
        for a in outlines:
            sid=_station_id(a)
            if not sid or sid in seen: continue
            name=a.get("text") or a.get("title") or a.get("name") or sid
            url=a.get("url") or ""
            if "tunein.com" not in url and "radiotime.com" not in url: url=f"https://tunein.com/radio/-{sid}/"
            results.append({"id":sid,"name":name,"url":url,"logo":a.get("image") or a.get("imageurl") or a.get("logo")})
            seen.add(sid)
            if len(results)>=20: break
        return results
    except Exception as e:
        raise HTTPException(502,f"TuneIn 검색 실패: {e}")

@app.get("/api/tunein/station/{station_id}")
async def tunein_station(station_id:str):
    if not station_id.startswith("s"): station_id="s"+station_id
    try:
        r=await tunein_get("Tune.ashx",{"id":station_id})
        parsed=_parse_tunein_response(r.text,r.headers.get("content-type",""))
        if isinstance(parsed,dict) and "__stream_urls__" in parsed:
            urls=parsed.get("__stream_urls__") or []
            if not urls: raise HTTPException(502,"TuneIn이 재생용 stream URL을 반환하지 않았습니다.")
            url=urls[0]
        else:
            outlines=_json_outlines(parsed) if isinstance(parsed,(dict,list)) else _flatten_outlines(parsed)
            pick=_pick_stream(outlines)
            if not pick: raise HTTPException(502,"TuneIn이 재생용 raw stream URL을 반환하지 않았습니다.")
            _,url,_=pick
        # Always relay TuneIn through QNAP and transcode to MP3 for DLNA compatibility.
        stream_url=f"{PUBLIC_STREAM_BASE_URL}/stream/tunein?url={urllib.parse.quote(url,safe='')}"
        return {"id":station_id,"name":station_id,"stream_url":stream_url,"source_url":url,"mime":"audio/mpeg"}
    except HTTPException: raise
    except Exception as e:
        raise HTTPException(502,f"TuneIn 방송국 확인 실패: {type(e).__name__}: {e}")

@app.get("/api/radios")
def radios():
    if not RADIO_FILE.exists(): return []
    return __import__("json").loads(RADIO_FILE.read_text(encoding="utf-8"))

@app.post("/api/play")
def play(req:PlayRequest):
    # Server-side safety net for stale clients: rewrite raw non-MP3 audio URLs.
    media_url=req.media_url
    if ENABLE_TRANSCODE and req.kind=="audio" and "/media/" in media_url:
        tail=media_url.split("/media/",1)[1].split("?",1)[0]
        if Path(urllib.parse.unquote(tail)).suffix.lower() != ".mp3":
            media_url=f"{PUBLIC_STREAM_BASE_URL}/stream/audio/{tail}"
    c=control_url(req.renderer_url)
    mime=(req.mime or "audio/mpeg") if req.kind=="audio" else req.mime
    meta=didl(req.title,media_url,mime,req.kind)
    import xml.sax.saxutils as sax
    body=f"<InstanceID>0</InstanceID><CurrentURI>{sax.escape(media_url)}</CurrentURI><CurrentURIMetaData>{sax.escape(meta)}</CurrentURIMetaData>"
    soap(c,"SetAVTransportURI",body); soap(c,"Play","<InstanceID>0</InstanceID><Speed>1</Speed>")
    return {"ok":True,"media_url":media_url}

@app.post("/api/control")
def control(req:ControlRequest):
    c=control_url(req.renderer_url)
    a=req.action.upper()
    if a in {"PLAY","PAUSE","STOP","NEXT","PREVIOUS"}:
        body="<InstanceID>0</InstanceID>"
        if a=="PLAY": body+="<Speed>1</Speed>"
        soap(c,a.title() if a!="NEXT" and a!="PREVIOUS" else a.title(),body)
    elif a=="SEEK":
        soap(c,"Seek",f"<InstanceID>0</InstanceID><Unit>REL_TIME</Unit><Target>{req.value or '00:00:00'}</Target>")
    else: raise HTTPException(400,"Unsupported action")
    return {"ok":True}

@app.get("/api/status")
def status(renderer_url:str):
    c=control_url(renderer_url)
    def get(action,body):
        try:
            r=soap(c,action,body)
            return r.text
        except: return ""
    return {"transport":get("GetTransportInfo","<InstanceID>0</InstanceID>"),
            "position":get("GetPositionInfo","<InstanceID>0</InstanceID>")}

@app.get("/api/volume")
def volume(renderer_url:str):
    c=control_url(renderer_url,"RenderingControl")
    r=soap(c,"GetVolume","<InstanceID>0</InstanceID><Channel>Master</Channel>","RenderingControl")
    return {"xml":r.text}

@app.post("/api/volume")
def set_volume(req:ControlRequest):
    c=control_url(req.renderer_url,"RenderingControl")
    v=max(0,min(100,int(req.value or 0)))
    soap(c,"SetVolume",f"<InstanceID>0</InstanceID><Channel>Master</Channel><DesiredVolume>{v}</DesiredVolume>","RenderingControl")
    return {"ok":True,"volume":v}

@app.post("/api/youtube")
def youtube(req:SearchRequest):
    from yt_dlp import YoutubeDL
    opts={"quiet":True,"skip_download":True,"extract_flat":True,
          "extractor_args":{"youtube":{"player_client":["default","web_embedded"]}}}
    with YoutubeDL(opts) as y:
        info=y.extract_info(req.q if req.q.startswith("http") else "ytsearch10:"+req.q,download=False)
    return [{"title":e.get("title"),"url":e.get("webpage_url") or e.get("url"),"duration":e.get("duration")} for e in info.get("entries",[])[:10]]

def _ffmpeg_stream(url, extra=None, input_headers=None):
    cmd=["ffmpeg","-hide_banner","-loglevel","warning","-nostdin","-reconnect","1","-reconnect_streamed","1","-reconnect_on_network_error","1","-reconnect_delay_max","5"]
    if input_headers:
        hdr="".join(f"{k}: {v}\r\n" for k,v in input_headers.items())
        cmd += ["-headers",hdr]
    if extra: cmd += extra
    cmd += ["-i",url,"-vn","-c:a","libmp3lame","-b:a","192k","-f","mp3","pipe:1"]
    return subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,bufsize=0)

def _stream_generator(p):
    try:
        while True:
            chunk=p.stdout.read(64*1024)
            if not chunk: break
            yield chunk
    finally:
        try: p.kill()
        except: pass
        try: p.wait(timeout=2)
        except: pass
        try:
            err=p.stderr.read().decode("utf-8","ignore")[-2000:]
            if err: print("FFmpeg stream: "+err,flush=True)
        except: pass

@app.get("/stream/youtube")
def youtube_stream(url:str):
    from yt_dlp import YoutubeDL
    base={"quiet":True,"no_warnings":True,"format":"bestaudio[ext=m4a]/bestaudio/best","noplaylist":True}
    fast_opts={**base,"extractor_args":{"youtube":{"player_client":["web_embedded"]}}}
    fallback_opts={**base,"extractor_args":{"youtube":{"player_client":["default","web_embedded"]}}}
    now=time.time()
    with YOUTUBE_CACHE_LOCK:
        cached=YOUTUBE_CACHE.get(url)
        direct=cached[0] if cached and cached[1] > now else None
    if not direct:
        last_err=None
        for opts in (fast_opts,fallback_opts):
            try:
                with YoutubeDL(opts) as y:
                    i=y.extract_info(url,download=False)
                direct=i.get("url")
                if direct: break
            except Exception as e:
                last_err=e
        if not direct: raise HTTPException(502,"YouTube stream unavailable: "+str(last_err or "unknown error"))
        with YOUTUBE_CACHE_LOCK: YOUTUBE_CACHE[url]=(direct,time.time()+YOUTUBE_CACHE_TTL)
    p=_ffmpeg_stream(direct)
    return StreamingResponse(_stream_generator(p),media_type="audio/mpeg",headers={"Cache-Control":"no-store","X-DLNA-Source":"youtube"})

@app.get("/stream/tunein")
def tunein_stream(url:str):
    # Force a stable MP3 output. This avoids renderer-specific AAC/HLS/ICY issues.
    p=_ffmpeg_stream(url,input_headers={"User-Agent":"Mozilla/5.0 DLNA-Home-Cast/3.8"})
    return StreamingResponse(_stream_generator(p),media_type="audio/mpeg",headers={"Cache-Control":"no-store","icy-metadata":"0","X-DLNA-Source":"tunein"})

@app.get("/stream/audio-direct/{path:path}")
def stream_audio_direct(path:str):
    # Direct FLAC path for DLNA renderers that natively support FLAC (e.g. U5 Mini/RX-A3060).
    # Bypasses the MP3 transcoding path and serves the original file with audio/flac.
    p=safe_path(path)
    if not p.is_file(): raise HTTPException(404)
    if p.suffix.lower() != ".flac":
        raise HTTPException(400,"FLAC 직접 재생은 .flac 파일만 지원합니다.")
    return FileResponse(p,media_type="audio/flac",filename=p.name,headers={"Cache-Control":"no-store","Accept-Ranges":"bytes"})

@app.get("/stream/audio/{path:path}")
def stream_audio(path:str):
    p=safe_path(path)
    if not p.is_file(): raise HTTPException(404)
    if not ENABLE_TRANSCODE:
        return FileResponse(p,media_type=mimetypes.guess_type(str(p))[0] or "application/octet-stream")
    if p.suffix.lower()==".mp3":
        return FileResponse(p,media_type="audio/mpeg",headers={"Cache-Control":"no-store"})
    return _audio_transcode_response(p)

@app.get("/stream/file/{path:path}")
def stream_file(path:str):
    p=safe_path(path)
    if not p.is_file(): raise HTTPException(404)
    mime=mimetypes.guess_type(str(p))[0] or "application/octet-stream"
    return FileResponse(p,media_type=mime)

@app.get("/health")
def health(): return {"ok":True}
