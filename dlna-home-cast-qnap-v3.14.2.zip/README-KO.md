# DLNA Home Cast QNAP v3.8.1

## 중요: 이번 버전은 QNAP Container Station의 Dockerfile 경로 오류를 피하도록 `build:`를 사용하지 않습니다.

기존 오류:
`failed to read dockerfile: open Dockerfile: no such file or directory`

v3.8.1은 `python:3.12-slim` 이미지를 직접 사용하고 컨테이너 시작 시 필요한 패키지를 설치합니다.
따라서 Container Station이 별도 빌드 디렉터리에서 Dockerfile을 찾을 필요가 없습니다.

---

# 1. QNAP 폴더 만들기

QNAP File Station에서 다음 폴더를 만드세요.

`/share/Container/dlna-home-cast`

압축 해제 후 **아래 구조가 정확해야 합니다.**

```text
/share/Container/dlna-home-cast/
├── docker-compose.yml
├── Dockerfile
├── requirements.txt
├── app/
│   ├── __init__.py
│   ├── __main__.py
│   └── static/
└── data/
    └── radios.json
```

`Dockerfile`은 v3.8.1에서는 사용하지 않습니다. 기존 파일을 보관해 둔 것이며, Container Station에서 Dockerfile을 직접 빌드할 필요가 없습니다.

## 절대 이렇게 하지 마세요

```text
/share/Container/dlna-home-cast/dlna-home-cast-qnap-v3.8.1/
    docker-compose.yml
```

처럼 한 단계 더 들어가면 안 됩니다.

---

# 2. NAS 미디어 폴더 확인

기본 설정은:

```text
QNAP 실제 폴더: /share/Multimedia
컨테이너 내부:  /media
```

즉 Compose의:

```yaml
- /share/Multimedia:/media:ro
```

가 실제 NAS 폴더와 일치해야 합니다.

QNAP SSH에서 확인:

```bash
ls -la /share/Multimedia
```

---

# 3. Container Station 설치

Container Station 실행

`애플리케이션` → `생성`

`docker-compose.yml`을 이용해 Application을 생성합니다.

## 중요

이번 v3.8.1의 `docker-compose.yml`에는 다음이 없습니다.

```yaml
build:
```

따라서 Dockerfile을 별도로 지정하거나 Build 경로를 설정하지 않아도 됩니다.

Container Station이 `python:3.12-slim` 이미지를 Docker Hub에서 가져온 뒤 컨테이너 안에서 필요한 패키지를 설치합니다.

첫 실행은 패키지 설치 때문에 몇 분 정도 걸릴 수 있습니다.

---

# 4. QNAP 네트워크 설정

DLNA 검색은 일반 HTTP와 다르게 SSDP 멀티캐스트를 사용합니다.

DLNA 장치 검색:

```text
239.255.255.250:1900 / UDP
```

따라서 v3.8.1은:

```yaml
network_mode: host
```

를 사용합니다.

## 권장 네트워크

```text
공유기
   │
   ├── QNAP
   │    192.168.0.20
   │
   ├── TV / AV Receiver / 스피커
   │    192.168.0.x
   │
   └── PC / 스마트폰
        192.168.0.x
```

QNAP과 DLNA 기기는 가능하면 같은 LAN/VLAN에 두세요.

---

# 5. 공유기에서 확인할 것

다음 기능이 켜져 있으면 DLNA 검색이 안 될 수 있습니다.

- AP Isolation
- Client Isolation
- Wireless Isolation
- Guest Network 격리
- VLAN 간 멀티캐스트 차단
- IGMP Snooping/Multicast 설정 문제

특히 TV나 AV Receiver가 Guest Wi-Fi에 연결되어 있다면 일반 Wi-Fi/LAN으로 옮기는 것을 권장합니다.

---

# 6. 포트

웹 접속:

```text
TCP 8090
```

DLNA 검색:

```text
UDP 1900
```

QNAP 내부에서 사용할 경우 공유기의 포트포워딩은 필요하지 않습니다.

외부 인터넷에 TCP 8090을 그대로 공개하는 것도 권장하지 않습니다.

---

# 7. 접속

설치가 정상적으로 완료되면 PC/스마트폰 브라우저에서:

```text
http://192.168.0.20:8090
```

접속합니다.

---

# 8. DLNA 기기 검색

웹 화면에서 `DLNA 기기` 또는 `기기 선택`을 누르면 SSDP 검색을 실행합니다.

예:

```text
거실 AV Receiver
거실 TV
안방 스피커
주방 스피커
```

등 실제 네트워크에서 발견되는 MediaRenderer를 표시합니다.

기기를 한 번 선택하면 `settings.json`에 저장되고 이후 NAS/라디오/YouTube 재생 시 같은 기기를 우선 사용합니다.

---

# 9. TuneIn

TuneIn 탭에서:

```text
검색어 입력
      ↓
방송국 검색
      ↓
방송국 선택
      ↓
현재 DLNA 기기로 재생
```

방송국 스트림을 확인할 수 없는 경우 해당 방송국의 스트림 정책/지역 제한 때문에 재생되지 않을 수 있습니다.

---

# 10. YouTube

YouTube 검색에는 `yt-dlp`를 사용합니다.

v3.3 컨테이너 시작 시:

```text
requirements.txt
        ↓
pip install
        ↓
yt-dlp 설치
```

가 자동으로 수행됩니다.

FFmpeg도 컨테이너 시작 시 설치됩니다.

---

# 11. 설치 후 로그 확인

Container Station에서 `dlna-web` 로그를 확인합니다.

정상이라면 대략:

```text
[DLNA Home Cast] Installing system packages...
[DLNA Home Cast] Installing Python packages...
[DLNA Home Cast] Starting web server on :8090...
```

이후 uvicorn이 8090 포트에서 실행됩니다.

---

# 12. Health Check

브라우저에서:

```text
http://192.168.0.20:8090/health
```

접속해서:

```json
{"ok":true}
```

가 나오면 웹 서버가 정상입니다.

---

# 13. 여전히 DLNA가 검색되지 않을 때

웹 접속은 되는데 DLNA 기기가 안 보이면 Docker 문제보다 네트워크 문제일 가능성이 높습니다.

확인 순서:

1. QNAP과 TV/AV Receiver의 IP 확인
2. 두 장치가 같은 `192.168.0.x` 대역인지 확인
3. Guest Wi-Fi인지 확인
4. AP/Client Isolation 해제
5. QNAP 방화벽 확인
6. 공유기의 멀티캐스트/IGMP 설정 확인
7. AV Receiver의 Network Standby / Network Control 설정 확인
8. Container Station에서 `dlna-web` 재시작

---

# 14. 중요: v3.8.1의 Docker 구조

기존 v3.1:

```text
Container Station
      ↓
docker-compose.yml
      ↓
build: ...
      ↓
Dockerfile 검색
      ↓
경로 오류 ❌
```

v3.8.1:

```text
Container Station
      ↓
docker-compose.yml
      ↓
python:3.12-slim 이미지
      ↓
/share/Container/dlna-home-cast → /app
      ↓
pip install
      ↓
uvicorn 실행
      ↓
정상 실행
```

이 방식은 Dockerfile의 Compose build context 문제를 아예 제거합니다.

---

# 15. 첫 실행 시 주의

컨테이너를 처음 시작할 때 인터넷에서 다음을 받아옵니다.

- Python 패키지
- FFmpeg
- 인증서 패키지

따라서 QNAP이 인터넷에 연결되어 있어야 첫 설치가 완료됩니다.

설치 완료 후에는 일반적으로 웹 앱 사용에 인터넷이 필요한 기능과 그렇지 않은 기능이 나뉩니다.

- NAS 파일 재생: 로컬 네트워크
- DLNA 검색: 로컬 네트워크
- TuneIn: 인터넷 필요
- YouTube: 인터넷 필요


## Container Station에서 "먼저 필요한 모든 설정을 구성했는지 확인하십시오"가 표시될 때

이 메시지는 Compose 생성 화면의 검증 단계에서 표시될 수 있습니다.

v3.3에서는 Compose YAML의 healthcheck 인용부호 문제를 수정했습니다.
이전 v3.8.1의 일부 Container Station/Compose 파서에서 잘못 해석될 수 있던 중첩 따옴표를 제거했습니다.

또한 이번 버전은 `build:`를 사용하지 않으므로 Dockerfile 경로를 설정할 필요가 없습니다.

Container Station에서 애플리케이션 이름은 예를 들어:

`dlna-home-cast`

로 지정하세요.

YAML 파일을 불러온 뒤 **생성/적용**을 누르고, 오류가 나오면 그 화면을 캡처해 주세요.


## v3.4 수정사항
- YouTube/TuneIn/NAS 재생 요청에서 `url` 대신 API가 요구하는 `media_url`을 일관되게 사용하도록 수정했습니다.
- 기존 브라우저 코드가 남아 있어도 `send()`에서 `url`을 `media_url`로 보정합니다.
- QNAP 공유 폴더 실제 이름이 `Multimedia`인 환경에 맞춰 `/share/Multimedia:/media:ro`로 수정했습니다.


## v3.5 수정사항
- TuneIn Search.ashx 요청에 `render=json`을 사용하도록 수정했습니다.
- Tune.ashx가 반환하는 M3U 재생목록을 XML로 잘못 파싱하던 문제를 수정했습니다.
- M3U 안의 실제 `http://` 또는 `https://` 스트림 URL을 추출해 DLNA로 전달합니다.
- HLS `.m3u8` 스트림은 `application/vnd.apple.mpegurl`로 처리합니다.


## v3.8 수정사항
- FLAC/OGG/OPUS/WAV/M4A 등 NAS 오디오를 QNAP에서 MP3로 변환해 DLNA 호환성을 높였습니다. 변환 결과는 data/transcode에 캐시됩니다.
- TuneIn 응답을 XML로만 가정하지 않고 M3U/일반 URL도 처리합니다. TuneIn 스트림은 QNAP에서 MP3로 릴레이/변환합니다.
- TuneIn HLS(.m3u8) 및 AAC 등 DLNA에서 직접 재생하기 어려운 스트림도 MP3로 변환하도록 했습니다.
- YouTube를 yt-dlp 2026.08.19로 업데이트하고 yt-dlp[default] 및 Deno JS runtime을 사용하도록 변경했습니다.
- YouTube도 QNAP에서 MP3로 변환해 DLNA에 전달하므로 WebM/Opus와 MIME 불일치 문제를 줄였습니다.
- YouTube extractor client에 default + web_embedded를 사용합니다.


## 리시버 변경

화면 상단의 **🔄 리시버 변경** 버튼을 누르면 현재 네트워크에서 DLNA MediaRenderer를 다시 검색합니다.

1. **🔄 리시버 변경**을 클릭합니다.
2. 검색된 DLNA 리시버 목록에서 원하는 기기를 선택합니다.
3. 선택한 기기는 `data/settings.json`에 저장되어 이후 NAS/라디오/TuneIn/YouTube 재생의 기본 리시버가 됩니다.
4. 현재 재생 중인 기존 리시버는 자동으로 정지하지 않으며, **다음 재생부터 새 리시버로 전송**합니다.
5. 목록에 안 보이면 **🔄 다시 검색**을 눌러 SSDP를 재검색합니다.

> 리시버 검색은 SSDP 멀티캐스트(`239.255.255.250:1900/UDP`)를 사용하므로 QNAP과 DLNA 리시버가 같은 LAN/VLAN에 있고 AP/공유기의 클라이언트 격리가 꺼져 있어야 합니다.


## v3.8 변경사항
- FLAC/무손실 등 NAS 오디오는 `/stream/audio/...`에서 MP3로 변환 후 DLNA에 전달합니다.
- 브라우저 캐시 문제를 막기 위해 `app.js?v=3.8.0`로 강제 버전 갱신합니다.
- `🔄 리시버 변경`에서 새 리시버를 선택하면 마지막 재생 항목을 새 리시버로 실제 이동합니다.
- TuneIn은 QNAP에서 MP3로 중계하며 User-Agent/재접속 옵션을 추가했습니다.
- YouTube 스트림은 안정적인 m4a 오디오를 우선 선택하고 추출 결과를 MP3로 변환합니다.
